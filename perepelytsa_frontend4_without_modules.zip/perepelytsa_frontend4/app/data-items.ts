import { Item } from './item';
export var ITEMS: Item[] = [
{name:'HTX Actinum 5701',itemPrice:100,quantity:1,url:'http://goo.gl/bi2r8x'},
{name:'HTX Actinum 5701',itemPrice:120,quantity:2,url:'http://goo.gl/bi2r8x'},
{name:'HTX Actinum 5701',itemPrice:150,quantity:3,url:'http://goo.gl/bi2r8x'}
]; 