function addtoCart(){	
document.getElementById("shopping-cart-badge").style.visibility="visible";
var quant=document.getElementById("quant");
var strUser = quant.options[quant.selectedIndex].text;
if(parseInt(document.getElementById("shopping-cart-badge").textContent)+parseInt(strUser)>5)alert("Pay first")
else
document.getElementById("shopping-cart-badge").textContent=parseInt(document.getElementById("shopping-cart-badge").textContent)+parseInt(strUser);
}

function mychangemainImg(el){
	document.getElementById("mainimg").src=el.getAttribute("src");
}

function shiptoUkraine(){
	var x = document.getElementById("shipto").value;
	var imgs=document.getElementsByClassName("col-sm-9")[0].getElementsByClassName("bg-4");
	if(x=="Ukraine"){
	for(var i=0; i<imgs.length; i=i+2){
		imgs[i].textContent="Shipping to Ukraine";
	}
}else{
	for(var i=0; i<imgs.length; i=i+2){
		imgs[i].textContent="HTX Actinum 5701";
	}
}

}

function mymouseLeftFunction(el){
el.src="http://www.uabike.com/assets/images/article/news/2013-merida-mountain-bikes-add-new-vpk-suspension/2013-Merida-Ninety-Nine-29er-race-mountain-bike-600x376.jpg";
}
function mymouseOverFunction(el){
	
el.src="http://bikecolony.com/sites/default/files/big-nine-carbon-team-2013-2_1.jpg";
}
 <!-- function 5 - clear cart on new badge click-->
function clearCart(){
	document.getElementById("shopping-cart-badge").textContent=0;
}